VASTAV — PC DATABASE + EMAIL ALERTS + ONLINE ACCESS
===================================================

WHAT THIS PROJECT DOES
- Preserves your existing VASTAV website design and form (index.html is copied from final Vastav.html).
- Stores each submission in data/vastav.db on this PC using SQLite.
- Sends a Gmail notification to rastogipuranjay42@gmail.com for each new report.
- Provides the existing API endpoints used by the website: create report, dashboard, tracking, and official status updates.
- Keeps citizen name, phone, and email out of the public dashboard/tracking API responses.
- Supports CSV export of all saved submissions.

REQUIREMENTS
- Windows 10/11 PC
- Python 3.10 or newer (3.11/3.12 recommended)
- Internet connection for Gmail alerts and public online access
- Google App Password for the sending Gmail account (not your normal Gmail password)

PART A — RUN ON YOUR PC
1. Extract this ZIP to a normal folder, e.g. C:\VASTAV-PC-Online.
2. Install Python from https://www.python.org/downloads/ if needed. During installation, tick "Add Python to PATH".
3. Open the extracted folder in VS Code.
4. In VS Code choose Terminal > New Terminal.
5. Create a virtual environment and install dependencies:

   py -m venv .venv
   .venv\Scripts\activate
   py -m pip install -r requirements.txt

   If the py command is not recognized, try python instead of py.

6. Copy .env.example and name the copy .env. Do not rename or overwrite .env.example.
   In VS Code, right-click .env.example > Copy, then paste and rename the copy to .env.
7. Open .env and set the email credentials and admin token (Part B below).
8. Start the server:

   py app.py

9. Open http://127.0.0.1:5000 in your browser. The /health page at
   http://127.0.0.1:5000/health should show {"ok":true,...}.
10. Leave the terminal window open while using VASTAV. The SQLite file is saved at data\vastav.db.

PART B — ENABLE EMAIL ALERTS WITH GMAIL
1. Sign in to the Google account that will SEND alerts. It can be the same address as the destination inbox.
2. Turn on 2-Step Verification for that Google account if it is not already enabled.
3. Open Google Account > Security > App passwords. Google may require you to search for "App passwords" in account settings. Create an app password for VASTAV.
4. Copy the generated 16-character app password into VASTAV_EMAIL_APP_PASSWORD in .env. Remove spaces.
5. Set VASTAV_EMAIL_USER=rastogipuranjay42@gmail.com and NOTIFICATION_EMAIL=rastogipuranjay42@gmail.com (or use another sender/recipient if preferred).
6. Generate an official status token in the VS Code terminal:

   py -c "import secrets; print(secrets.token_urlsafe(32))"

   Copy the output into VASTAV_ADMIN_TOKEN in .env. Keep it private.
7. Stop the server with Ctrl+C and start it again using py app.py.
8. Submit a test report using your own test details. Check your inbox and Spam folder.

IMPORTANT EMAIL NOTES
- Never put your Gmail password or app password in index.html.
- Never paste the .env file or app password into chat or screenshots.
- If the report is saved but email is not configured or Gmail rejects it, the server terminal logs the email error; the database record remains saved.
- If your Google account does not offer App passwords, use an approved SMTP/email provider and update send_report_email() accordingly.

PART C — MAKE THE PC-HOSTED WEBSITE ACCESSIBLE ONLINE
The app is hosted on your PC, so the PC must be ON, connected to the internet, and running app.py. A tunnel exposes the local web server without opening router ports.

QUICK TUNNEL TEST (temporary URL)
1. Keep app.py running.
2. Install cloudflared from Cloudflare's official guide: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
3. Open a SECOND terminal window and run:

   cloudflared tunnel --url http://127.0.0.1:5000

4. Wait for the https://...trycloudflare.com URL printed in that terminal.
5. Open that URL on your phone or share it with testers. Use the exact URL shown by cloudflared.
6. Keep both terminals open. The temporary URL can change when the tunnel restarts.

For a stable long-term web address, set up a named Cloudflare Tunnel attached to a domain you control. Follow Cloudflare's current official instructions; do not share your tunnel token publicly.

If you stop the Python server, shut down the PC, lose internet, or close the tunnel terminal, the online site will not accept new reports. Reports already saved in SQLite remain on your PC.

PART D — EXPORT REPORTS TO EXCEL/CSV
After at least one report is saved, open a terminal in this folder and run:

   py export_reports.py

A CSV file will appear in the exports folder. Open it in Excel. This CSV contains personal details, so keep it private.

BACKUP YOUR DATABASE
- Stop app.py with Ctrl+C before copying data\vastav.db to a safe backup folder or external drive.
- Keep backups private because the database contains names, phone numbers, and email addresses.
- Do not delete data\vastav.db if you want to keep the submissions.

HOW OFFICIAL STATUS UPDATES WORK
The existing Track page asks officials for the token. Enter the value of VASTAV_ADMIN_TOKEN from .env when changing a report status. Never share that token with the public.

PRIVACY / SAFETY
- The online dashboard and public tracking API do not return citizen phone numbers or email addresses.
- Email notifications and the local SQLite database contain the full submission details, as requested.
- This is a local-first setup, not a managed cloud database. Your PC is the authoritative database host.
- Use HTTPS through the tunnel for internet access. Do not port-forward Flask/Waitress directly on your router.
- Test with dummy information before collecting real reports.

TROUBLESHOOTING
- "py is not recognized": try python; if neither works, install Python and enable PATH.
- "ModuleNotFoundError": activate .venv and run py -m pip install -r requirements.txt again.
- Email error: confirm the sender address, app password, 2-Step Verification, internet access, and spam folder.
- Website won't load online: confirm both terminals are running and use the current trycloudflare.com URL.
- Port 5000 already in use: change PORT=5001 in .env, restart app.py, and tunnel http://127.0.0.1:5001 instead.

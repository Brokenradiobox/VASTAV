"""Export all VASTAV submissions from SQLite to a CSV spreadsheet."""
import csv, json, sqlite3
from datetime import datetime
from pathlib import Path
BASE = Path(__file__).resolve().parent
DB = BASE / "data" / "vastav.db"
OUT = BASE / "exports"
OUT.mkdir(exist_ok=True)
if not DB.exists():
    raise SystemExit("Database not found yet. Start VASTAV and receive at least one report first.")
with sqlite3.connect(DB) as con:
    rows = con.execute("SELECT report_json FROM reports ORDER BY created_at DESC").fetchall()
reports = [json.loads(row[0]) for row in rows]
fields = sorted({key for report in reports for key in report.keys()})
path = OUT / f"vastav-reports-{datetime.now():%Y%m%d-%H%M%S}.csv"
with path.open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(reports)
print(f"Exported {len(reports)} report(s) to: {path}")

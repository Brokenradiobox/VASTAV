"""VASTAV local-first web server: SQLite storage + email alerts."""
from __future__ import annotations
import json
import os
import re
import smtplib
import sqlite3
import secrets
import hmac
from contextlib import contextmanager
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from threading import Lock
from flask import Flask, jsonify, request, send_from_directory
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "vastav.db"
DATA_DIR.mkdir(exist_ok=True)
load_dotenv(BASE_DIR / ".env")

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB JSON request limit
_db_lock = Lock()

VALID_STATUSES = {"SUBMITTED", "UNDER_REVIEW", "APPROVED", "IN_PROGRESS", "RESOLVED", "REJECTED", "DUPLICATE"}
PUBLIC_FIELDS = {
    "id", "rid", "at", "desc", "loc", "lmk", "cat", "dep", "p", "ex", "st", "note",
    "sev", "pop", "days", "rec", "saf", "cost", "map", "photo", "lat", "lng", "pending"
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect_db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


@contextmanager
def db_session():
    con = connect_db()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def init_db() -> None:
    with db_session() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                rid TEXT PRIMARY KEY,
                client_id TEXT UNIQUE,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                description TEXT NOT NULL,
                location TEXT NOT NULL,
                category TEXT NOT NULL,
                status TEXT NOT NULL,
                email_sent INTEGER NOT NULL DEFAULT 0,
                email_error TEXT,
                report_json TEXT NOT NULL
            )
        """)
        con.execute("CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at DESC)")


def clean_report(raw: dict) -> dict:
    """Keep the website's existing field names while validating server-side."""
    if not isinstance(raw, dict):
        raise ValueError("Invalid report data")
    r = dict(raw)
    for key in ("name", "phone", "email", "desc", "loc"):
        if not str(r.get(key, "")).strip():
            raise ValueError(f"Please provide {key}.")
    r["name"] = str(r["name"]).strip()[:120]
    r["phone"] = str(r["phone"]).strip()[:40]
    r["email"] = str(r["email"]).strip()[:254]
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", r["email"]):
        raise ValueError("Please provide a valid email address.")
    r["desc"] = str(r["desc"]).strip()[:10000]
    r["loc"] = str(r["loc"]).strip()[:1000]
    r["lmk"] = str(r.get("lmk", ""))[:500]
    r["cat"] = str(r.get("cat", "General Maintenance"))[:120]
    r["dep"] = str(r.get("dep", "General Maintenance Department"))[:120]
    r["ex"] = str(r.get("ex", ""))[:2000]
    r["note"] = str(r.get("note", ""))[:2000]
    r["st"] = str(r.get("st", "SUBMITTED")).upper()
    if r["st"] not in VALID_STATUSES:
        r["st"] = "SUBMITTED"
    for key, default, low, high in (("p", 0, 0, 100), ("sev", 5, 1, 10), ("saf", 5, 1, 10), ("rec", 2, 1, 5), ("pop", 1, 1, 100000000), ("days", 0, 0, 1000000), ("cost", 0, 0, 100000000000)):
        try:
            value = int(float(r.get(key, default)))
        except (TypeError, ValueError):
            value = default
        r[key] = max(low, min(high, value))
    try:
        r["at"] = int(r.get("at") or int(datetime.now(timezone.utc).timestamp() * 1000))
    except (TypeError, ValueError):
        r["at"] = int(datetime.now(timezone.utc).timestamp() * 1000)
    r["rid"] = re.sub(r"[^A-Za-z0-9-]", "", str(r.get("rid", ""))).upper()[:40]
    if not r["rid"]:
        r["rid"] = "URB-" + secrets.token_hex(4).upper()
    r["id"] = str(r.get("id", r["rid"]))[:100]
    r["map"] = str(r.get("map", ""))[:2000]
    r["photo"] = str(r.get("photo", "Not provided"))[:2000]
    for key in ("lat", "lng"):
        try:
            r[key] = float(r[key]) if r.get(key) is not None else None
        except (TypeError, ValueError):
            r[key] = None
    r.pop("pending", None)
    return r


def fetch_report(con: sqlite3.Connection, rid: str) -> dict | None:
    row = con.execute("SELECT report_json FROM reports WHERE rid=?", (rid,)).fetchone()
    if not row:
        return None
    try:
        return json.loads(row["report_json"])
    except json.JSONDecodeError:
        return None


def public_report(report: dict) -> dict:
    """Never expose citizens' contact details through public dashboard/tracking APIs."""
    return {k: v for k, v in report.items() if k in PUBLIC_FIELDS}


def send_report_email(report: dict) -> tuple[bool, str | None]:
    """Send an alert through Gmail SMTP. Credentials are read only from .env."""
    sender = os.getenv("VASTAV_EMAIL_USER", "").strip()
    app_password = os.getenv("VASTAV_EMAIL_APP_PASSWORD", "").replace(" ", "").strip()
    recipient = os.getenv("NOTIFICATION_EMAIL", "rastogipuranjay42@gmail.com").strip()
    if not sender or not app_password:
        return False, "Email is not configured: set VASTAV_EMAIL_USER and VASTAV_EMAIL_APP_PASSWORD in .env"
    msg = EmailMessage()
    msg["Subject"] = f"VASTAV: New {report.get('p', 0)}/100 priority report — {report.get('rid', '')}"
    msg["From"] = sender
    msg["To"] = recipient
    submitted = datetime.fromtimestamp(report.get("at", 0) / 1000, timezone.utc).astimezone().strftime("%d %b %Y, %I:%M %p %Z")
    msg.set_content(f"""A new report has been submitted through VASTAV.

REPORT DETAILS
==============
Receipt / Tracking ID: {report.get('rid', '')}
Submitted: {submitted}
Citizen name: {report.get('name', '')}
Phone: {report.get('phone', '')}
Email: {report.get('email', '')}
Description: {report.get('desc', '')}
Category: {report.get('cat', '')}
Department: {report.get('dep', '')}
Location: {report.get('loc', '')}
Landmark: {report.get('lmk', '')}
Map link: {report.get('map', '')}
Priority score: {report.get('p', 0)}/100
Status: {report.get('st', 'SUBMITTED')}
Severity: {report.get('sev', '')}/10
Safety risk: {report.get('saf', '')}/10
Recurrence: {report.get('rec', '')}/5
People affected: {report.get('pop', '')}
Duration (days): {report.get('days', '')}
Estimated cost (INR): {report.get('cost', 0)}

Priority explanation: {report.get('ex', '')}
Photo / evidence reference: {report.get('photo', 'Not provided')}

This report has also been saved to the VASTAV SQLite database on the host PC.
""")
    try:
        with smtplib.SMTP("smtp.gmail.com", 587, timeout=20) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(sender, app_password)
            smtp.send_message(msg)
        return True, None
    except Exception as exc:  # database saving must still succeed if email has a temporary issue
        return False, f"{type(exc).__name__}: {str(exc)[:400]}"


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Permissions-Policy"] = "geolocation=(self)"
    return response


@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory(BASE_DIR, "manifest.webmanifest", mimetype="application/manifest+json")


@app.get("/icons/<path:filename>")
def app_icons(filename: str):
    return send_from_directory(BASE_DIR / "icons", filename)


@app.get("/sw.js")
def service_worker():
    response = send_from_directory(BASE_DIR, "sw.js", mimetype="application/javascript")
    response.headers["Cache-Control"] = "no-cache"
    return response


@app.get("/health")
def health():
    return jsonify({"ok": True, "app": "VASTAV", "storage": "SQLite", "database": "connected"})


@app.post("/api/reports")
def create_report():
    raw = request.get_json(silent=True)
    try:
        r = clean_report(raw)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    client_id = str((raw or {}).get("clientId") or r.get("id") or "")[:120]
    now = now_iso()
    with _db_lock, connect_db() as con:
        # The offline sync may retry a submission; return the existing row without emailing twice.
        if client_id:
            old = con.execute("SELECT rid, report_json FROM reports WHERE client_id=?", (client_id,)).fetchone()
            if old:
                return jsonify({"report": json.loads(old["report_json"]), "alreadySaved": True}), 200
        existing = con.execute("SELECT rid FROM reports WHERE rid=?", (r["rid"],)).fetchone()
        if existing:
            r["rid"] = "URB-" + secrets.token_hex(4).upper()
        r["pending"] = False
        try:
            con.execute("""INSERT INTO reports
                (rid, client_id, created_at, updated_at, name, phone, email, description, location, category, status, report_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (r["rid"], client_id or None, now, now, r["name"], r["phone"], r["email"], r["desc"], r["loc"], r["cat"], r["st"], json.dumps(r, ensure_ascii=False)))
        except sqlite3.IntegrityError:
            return jsonify({"error": "This report was already received. Please check your tracking ID."}), 409
    sent, mail_error = send_report_email(r)
    with _db_lock, connect_db() as con:
        con.execute("UPDATE reports SET email_sent=?, email_error=?, updated_at=? WHERE rid=?", (1 if sent else 0, mail_error, now_iso(), r["rid"]))
    if not sent:
        app.logger.warning("Report %s saved in SQLite but email alert failed: %s", r["rid"], mail_error)
    return jsonify({"report": r, "emailSent": sent, "message": "Report saved" if sent else "Report saved; email alert needs configuration or retry"}), 201


@app.get("/api/public/reports")
def public_reports():
    with db_session() as con:
        rows = con.execute("SELECT report_json FROM reports ORDER BY created_at DESC LIMIT 500").fetchall()
    return jsonify({"reports": [public_report(json.loads(row["report_json"])) for row in rows]})


@app.get("/api/track/<rid>")
def track_report(rid: str):
    with db_session() as con:
        r = fetch_report(con, rid.upper())
    if not r:
        return jsonify({"error": "Report not found"}), 404
    return jsonify({"report": public_report(r)})


@app.patch("/api/reports/<rid>/status")
def update_status(rid: str):
    expected = os.getenv("VASTAV_ADMIN_TOKEN", "").strip()
    supplied = request.headers.get("x-admin-token", "")
    if not expected or not hmac.compare_digest(supplied, expected):
        return jsonify({"error": "Invalid official access token"}), 401
    body = request.get_json(silent=True) or {}
    status = str(body.get("status", "")).upper()
    note = str(body.get("note", "")).strip()[:2000]
    if status not in VALID_STATUSES - {"DUPLICATE"}:
        return jsonify({"error": "Invalid status"}), 400
    if status == "RESOLVED" and not note:
        return jsonify({"error": "A resolution note is required"}), 400
    with _db_lock, connect_db() as con:
        r = fetch_report(con, rid.upper())
        if not r:
            return jsonify({"error": "Report not found"}), 404
        r["st"] = status
        r["note"] = note
        con.execute("UPDATE reports SET status=?, report_json=?, updated_at=? WHERE rid=?", (status, json.dumps(r, ensure_ascii=False), now_iso(), rid.upper()))
    return jsonify({"report": r})


if __name__ == "__main__":
    init_db()
    print("\nVASTAV server is starting")
    print("Local website: http://127.0.0.1:5000")
    print(f"SQLite database: {DB_PATH}")
    print("Health check: http://127.0.0.1:5000/health\n")
    from waitress import serve
    serve(app, host="127.0.0.1", port=int(os.getenv("PORT", "5000")), threads=8)
